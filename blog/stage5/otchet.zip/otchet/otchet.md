---
## Front matter
title: "Отчёт по 5 этапу индивидуального проекта"
subtitle: "Дисциплина: Операционные системы"
author: "Горпинич Елена Михайловна"

## Generic otions
lang: ru-RU
toc-title: "Содержание"

## Bibliography
bibliography: bib/cite.bib
csl: pandoc/csl/gost-r-7-0-5-2008-numeric.csl

## Pdf output format
toc: true # Table of contents
toc-depth: 2
lof: true # List of figures
lot: true # List of tables
fontsize: 12pt
linestretch: 1.5
papersize: a4
documentclass: scrreprt
## I18n polyglossia
polyglossia-lang:
  name: russian
  options:
	- spelling=modern
	- babelshorthands=true
polyglossia-otherlangs:
  name: english
## I18n babel
babel-lang: russian
babel-otherlangs: english
## Fonts
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase,Scale=0.9
## Biblatex
biblatex: true
biblio-style: "gost-numeric"
biblatexoptions:
  - parentracker=true
  - backend=biber
  - hyperref=auto
  - language=auto
  - autolang=other*
  - citestyle=gost-numeric
## Pandoc-crossref LaTeX customization
figureTitle: "Рис."
tableTitle: "Таблица"
listingTitle: "Листинг"
lofTitle: "Список иллюстраций"
lotTitle: "Список таблиц"
lolTitle: "Листинги"
## Misc options
indent: true
header-includes:
  - \usepackage{indentfirst}
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы

Добавить к сайту записи о персональных проектах и два поста (по прошедшей неделе и по теме: "Языки научного программирования ")



# Выполнение этапа №5

1)  Заходим /Users/elenagorpinich/work/blog/content/project/example и открываем файл в который добавим информацию о проектах (рис.[1])
![1](im/1.png)

2)  Cоздаём два файла для наших постов. Пишем команду hugo new post/ [имя файла].md. Она создает файл в формате Markdown, в который мы добавляем наш пост. (рис.[2-4])
![2](im/2.png)
![3](im/3.png)
![4](im/4.png)
3)  Запускаем hugo, заходим в каталог public, добавили файлы. Обновляем https://elenagorpinich.github.io/ и можем увидеть свои обновленные данные (рис.[5])
![5](im/5.png)

4) Зайдём на наш сайт и проверим изменения. (рис.[6-7])
![6](im/6.png)
![7](im/7.png)

# Вывод

Добавили к сайту записи о персональных проектах и два поста (по прошедшей неделе и по теме: "Языки научного программирования ")
